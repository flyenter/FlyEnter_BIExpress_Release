﻿
var arrValCompare = [
    { id: '>', text: '>' },
    { id: '>=', text: ">=" },
    { id: '<', text: '<' },
    { id: '<=', text: '<=' },
    { id: '=', text: '=' },
    { id: '<>', text: '<>' },
    { id: 'contain', text: 'contain' },
    { id: 'not contain', text: 'not contain' }
];