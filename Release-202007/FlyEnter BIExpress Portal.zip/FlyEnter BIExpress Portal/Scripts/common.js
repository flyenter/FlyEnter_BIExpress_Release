﻿var switchs = [{ id: 0, text: "N" }, { id: 1, text: "Y" }];
var isReportOrTask = [{ id: "Report", text: "Report" }, { id: "Task", text: "Task" }];
