﻿function My_GetWxMsgTempate(msgType) {

}